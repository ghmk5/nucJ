package com.github.hmdev.converter;

public enum RubyCharType
{
	NULL, KANJI, ALPHA, FULLALPHA, HIRAGANA, KATAKANA
}
